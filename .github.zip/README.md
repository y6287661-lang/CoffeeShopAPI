﻿# CoffeeShopAPI
مشروع API لإدارة متجر قهوة

## طريقة التشغيل
- dotnet build
- dotnet run

## المسارات المتاحة
- GET /api/users
- POST /api/orders